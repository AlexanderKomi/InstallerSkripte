#!/bin/bash

HDD_DIR="/media/alex/9d7f9fa6-a923-43f3-8ddf-24aca607368f/";

rmdir ~/Bilder;
rmdir ~/Dokumente;
rmdir ~/Backups;
rmdir ~/Programme;
rmdir ~/workspace;

ln -s $HDD_DIR ~/HDD;
ln -s $HDD_DIR"Bilder"      ~/Bilder;
ln -s $HDD_DIR"Dokumente"   ~/Dokumente;
ln -s $HDD_DIR"Backups"     ~/Backups;
ln -s $HDD_DIR"Programme"   ~/Programme;
ln -s $HDD_DIR"workspace"   ~/workspace;

