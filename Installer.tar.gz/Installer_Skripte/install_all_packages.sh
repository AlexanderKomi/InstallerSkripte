#!/bin/bash

cd ./externals;
chmod u+x ./install_externals.sh;
sudo ./install_externals.sh;
cd ..;


chmod u+x ./fucking_install_openscenegraph.sh;
sudo ./fucking_install_openscenegraph.sh;

chmod u+x ./install_dropbox.sh;
sudo ./install_dropbox.sh;

chmod u+x ./install_vscode.sh;
sudo ./install_vscode.sh;

chmod u+x ./install_spotify.sh;
sudo ./install_spotify.sh;

chmod u+x ./create_sym_links.sh;
sudo ./create_sym_links.sh;

chmod u+x ./install_lab.sh;
sudo ./install_lab.sh;

chmod u+x install_fzf.sh;
sudo ./install_fzf.sh;

chmod u+x ./install_ohmyzsh.sh;
sudo ./install_ohmyzsh.sh;

chmod u+x ./add_aliases.sh;
sudo ./add_aliaeses.sh;

