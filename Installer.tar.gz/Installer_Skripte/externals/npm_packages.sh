#!/bin/bash

# ------ NPM ------

sudo npm install npm@latest -g;
sudo npm -g install \
typescript \
angular \
react;
