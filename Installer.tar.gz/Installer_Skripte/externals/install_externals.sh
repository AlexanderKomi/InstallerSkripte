#!/bin/bash

chmod u+x \ 
./updagrade.sh \ 
./apt_packages.sh \ 
./pip_packages.sh  \ 
./npm_packages.sh  \ 
./snap_packages.sh 

sudo ./updagrade.sh;
sudo ./apt_packages.sh;
sudo ./pip_packages.sh;
sudo ./npm_packages.sh;
sudo ./snap_packages.sh;

