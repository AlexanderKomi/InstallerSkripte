#!/bin/bash

# ------ Snap ------

sudo snap refresh;
sudo snap install kotlin --classic;
snap install spotify;
snap install discord;