#!/bin/bash
# ------ Python 3 ------

sudo python3 -m pip install \
tensorflow \
numpy \
matplotlib \
bs4 \
keras \
pandoc \
howdoi
